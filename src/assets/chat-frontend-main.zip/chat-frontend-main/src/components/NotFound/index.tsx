import React from 'react';
import './style.css';

function NotFound() {
	return (
		<div className="not-found">
			<p>Page not found..</p>
		</div>
	);
}

export default NotFound;
